// script.js
// Optional: Add interactivity if needed in the future.